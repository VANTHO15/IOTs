# awsiot
ESP8266 / ESP32 examples with Amazon IoT
